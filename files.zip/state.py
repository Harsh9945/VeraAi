"""
In-memory state for the challenge bot.

Two stores:
  - contexts: keyed by (scope, context_id) -> {"version": int, "payload": dict}
    Idempotent on (context_id, version) per the testing brief §2.1.
  - conversations: keyed by conversation_id -> ConversationState
    Tracks turn history + a few derived flags (auto-reply streak, intent signal)
    used by the composer / validator / auto-reply detector.

Everything here is process-local. That's fine per the brief (§2.1: "storing in
memory is fine; just don't restart between calls").
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal


@dataclass
class ContextEntry:
    version: int
    payload: dict[str, Any]


@dataclass
class Turn:
    from_role: Literal["merchant", "customer", "vera"]
    message: str
    ts: str


@dataclass
class ConversationState:
    conversation_id: str
    merchant_id: str | None = None
    customer_id: str | None = None
    trigger_id: str | None = None
    turns: list[Turn] = field(default_factory=list)
    sent_bodies: list[str] = field(default_factory=list)  # anti-repetition check
    unanswered_nudges: int = 0
    ended: bool = False

    def last_n_merchant_messages(self, n: int) -> list[str]:
        msgs = [t.message for t in self.turns if t.from_role in ("merchant", "customer")]
        return msgs[-n:]


class Store:
    def __init__(self) -> None:
        self.contexts: dict[tuple[str, str], ContextEntry] = {}
        self.conversations: dict[str, ConversationState] = {}

    # ---- context ----

    def push_context(self, scope: str, context_id: str, version: int, payload: dict) -> tuple[bool, int | None]:
        """Returns (accepted, current_version_if_rejected)."""
        key = (scope, context_id)
        cur = self.contexts.get(key)
        if cur and cur.version >= version:
            return False, cur.version
        self.contexts[key] = ContextEntry(version=version, payload=payload)
        return True, None

    def get_context(self, scope: str, context_id: str | None) -> dict | None:
        if not context_id:
            return None
        entry = self.contexts.get((scope, context_id))
        return entry.payload if entry else None

    def counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for (scope, _) in self.contexts:
            counts[scope] = counts.get(scope, 0) + 1
        return counts

    def all_of_scope(self, scope: str) -> dict[str, dict]:
        return {cid: entry.payload for (s, cid), entry in self.contexts.items() if s == scope}

    # ---- conversations ----

    def get_or_create_conversation(self, conversation_id: str, merchant_id: str | None = None,
                                    customer_id: str | None = None, trigger_id: str | None = None) -> ConversationState:
        conv = self.conversations.get(conversation_id)
        if conv is None:
            conv = ConversationState(conversation_id=conversation_id, merchant_id=merchant_id,
                                      customer_id=customer_id, trigger_id=trigger_id)
            self.conversations[conversation_id] = conv
        return conv

    def teardown(self) -> None:
        self.contexts.clear()
        self.conversations.clear()


store = Store()
