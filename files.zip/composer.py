"""
The composer: turns (category, merchant, trigger, customer?) into a message.

Design notes (see README for the full rationale):
  - One shared system prompt encodes the rubric (specificity, category fit,
    merchant fit, trigger relevance, engagement compulsion) as constraints,
    not just guidance — the model is told exactly what loses points.
  - A small per-trigger-kind "framing hint" is injected, because a
    research_digest message and a recall_due message want different shapes
    (source-citation framing vs. slot-offering framing) even though they
    share the same 4-context input shape.
  - temperature=0 for determinism (the brief requires deterministic output
    given the same inputs for /v1/tick's composer; /v1/reply is allowed to
    vary turn to turn since it's genuinely conversational).
  - Output is forced JSON (via prompt + parsing) matching the exact schema
    the harness expects: body, cta, send_as, suppression_key, rationale.
"""

import json
import os
import re
from typing import Any

from anthropic import Anthropic

_client: Anthropic | None = None


def _get_client() -> Anthropic:
    global _client
    if _client is None:
        _client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    return _client


MODEL = os.environ.get("LLM_MODEL", "claude-sonnet-4-6")

SYSTEM_PROMPT = """You are the composer for Vera, magicpin's merchant-AI assistant. \
You write ONE outbound WhatsApp message per call, from structured context. You are being \
scored on a strict rubric — internalize it as hard constraints, not suggestions:

1. SPECIFICITY: anchor on a verifiable fact from the context — a number, date, headline, \
or citation that's ACTUALLY IN the context you were given. Never invent a statistic, a \
research citation, a competitor name, or an offer that isn't in the provided data. \
Fabrication is the single worst thing you can do — heavier penalty than a mediocre message.

2. CATEGORY FIT: match the category's voice profile exactly (tone, allowed vocabulary, taboos). \
Clinical/technical categories (dentists, doctors) want peer tone, not promotional hype. \
Respect every listed taboo word — never use it.

3. MERCHANT FIT: personalize using the merchant's actual name, performance numbers, offers, \
signals, and conversation history. Honor their language preference — if it's a Hindi-English \
mix, write in Hindi-English mix (Devanagari-free, Latin script Hinglish is fine and preferred \
for Indian merchants).

4. TRIGGER RELEVANCE: the message must make it obvious *why this message, why now* — tie \
explicitly to the trigger's kind and payload. Don't write a generic "improve your profile" \
message when you have a specific research digest / performance dip / recall date to point to.

5. ENGAGEMENT COMPULSION: use at least one of these levers — specificity/verifiability, loss \
aversion, social proof, effort externalization ("I've drafted X, just say go"), curiosity, \
reciprocity, or asking the merchant a direct question. Production Vera underuses social proof \
and "asking the merchant" — prefer these when they fit naturally.

HARD RULES:
- Exactly ONE call-to-action. Never offer multiple branching choices ("Reply YES for X, NO for Y").
- No preambles ("I hope you're doing well"). Don't re-introduce yourself if there's prior \
conversation history.
- Never repeat a message verbatim that appears in the conversation history you were given.
- Keep it concise — WhatsApp message length, not an email.
- If sending on behalf of the merchant to their customer, never make unverified medical/service \
claims and respect the category's customer-facing taboos strictly.

Respond with ONLY a JSON object, no markdown fences, no commentary:
{
  "body": "the message text",
  "cta": "binary" | "open_ended" | "none",
  "send_as": "vera" | "merchant_on_behalf",
  "suppression_key": "reuse the trigger's suppression_key if present, else invent a stable one",
  "rationale": "1 sentence: why this message, what lever(s) it uses"
}"""

# Per-trigger-kind framing hints. Keys match TriggerContext.kind values from
# the brief. Anything not listed falls back to a generic framing hint.
TRIGGER_FRAMING = {
    "research_digest_release": (
        "Framing: lead with the digest item, cite the source, connect it to the merchant's "
        "specific patient/customer cohort (from signals or customer_aggregate) if one is evident. "
        "End with a low-friction offer to do the next step for them."
    ),
    "recall_due": (
        "Framing (customer-facing): warm reminder, cite time since last visit, offer 1-2 concrete "
        "open slots with a real price from the merchant's active offers, single reply-a-number CTA."
    ),
    "perf_spike": (
        "Framing: open with the specific delta (e.g. '+28% views'), tie to a plausible cause if one "
        "is in context, suggest one concrete next action to capitalize on it."
    ),
    "perf_dip": (
        "Framing: loss-aversion opener with the specific delta, one concrete diagnostic/fix step, "
        "no alarmism."
    ),
    "milestone_reached": (
        "Framing: social-proof/celebration opener with the specific number, then bridge to one "
        "next-best-action."
    ),
    "competitor_opened": (
        "Framing: curiosity opener ('a new X opened near you') — DO NOT invent the competitor's name "
        "if it isn't in the payload. Bridge to a concrete defensive action."
    ),
    "dormant_with_vera": (
        "Framing: re-engagement, low-pressure, single easy question — not a hard sales push. "
        "Reference something specific and current, not generic 'just checking in'."
    ),
    "festival_upcoming": (
        "Framing: time-boxed urgency tied to the specific festival/date, one concrete campaign idea, "
        "effort-externalization ('I can set this up now')."
    ),
    "customer_lapsed_soft": (
        "Framing (customer-facing): warm, not guilt-tripping. Reference time since last visit and one "
        "concrete reason to come back (offer/service), single CTA."
    ),
    "appointment_tomorrow": (
        "Framing (customer-facing): short, purely confirmatory/reminder tone, minimal CTA."
    ),
}

DEFAULT_FRAMING = (
    "Framing: identify the single most compelling, verifiable fact across all provided context "
    "and build the message around it. Match urgency to the trigger's urgency field."
)


def _framing_for(trigger: dict[str, Any]) -> str:
    kind = trigger.get("kind", "")
    return TRIGGER_FRAMING.get(kind, DEFAULT_FRAMING)


def _extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    # strip markdown fences if the model added them anyway
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.MULTILINE)
    match = re.search(r"\{[\s\S]*\}", text)
    if not match:
        raise ValueError(f"No JSON object found in model output: {text[:200]}")
    return json.loads(match.group())


def compose(category: dict | None, merchant: dict | None, trigger: dict,
            customer: dict | None = None,
            conversation_history: list[str] | None = None) -> dict[str, Any]:
    """Deterministic single-shot composition (used by /v1/tick)."""

    payload = {
        "category": category or {},
        "merchant": merchant or {},
        "trigger": trigger,
        "customer": customer,
        "conversation_history_bodies_already_sent": conversation_history or [],
    }

    user_prompt = (
        f"{_framing_for(trigger)}\n\n"
        f"CONTEXT (JSON):\n{json.dumps(payload, indent=2, default=str)}\n\n"
        "Compose the message now. Return ONLY the JSON object described in your instructions."
    )

    client = _get_client()
    resp = client.messages.create(
        model=MODEL,
        max_tokens=600,
        temperature=0,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_prompt}],
    )
    raw = resp.content[0].text
    data = _extract_json(raw)

    data.setdefault("suppression_key", trigger.get("suppression_key", ""))
    data.setdefault("send_as", "merchant_on_behalf" if customer else "vera")
    data.setdefault("cta", "open_ended")
    return data


REPLY_SYSTEM_PROMPT = SYSTEM_PROMPT + """

You are now in REPLY mode: the merchant/customer just sent a message and you must decide the \
next move in an ongoing conversation. Respond with ONLY this JSON shape, no markdown fences:
{
  "action": "send" | "wait" | "end",
  "body": "message text (only if action=send)",
  "cta": "binary" | "open_ended" | "none" (only if action=send)",
  "wait_seconds": integer (only if action=wait, otherwise omit),
  "rationale": "1 sentence"
}

Rules for this mode:
- If the incoming message is clearly a canned auto-reply (generic "thank you for contacting" / \
"team will respond" style text with no real content), and this is the FIRST time you've seen it \
in this conversation, you may send ONE more low-friction nudge. If you detect the SAME pattern \
again, use action="end" — don't keep spending turns on an auto-reply loop.
- If the merchant/customer expresses clear commitment ("let's do it", "go ahead", "sign me up"), \
switch immediately to action mode — do NOT ask another qualifying question. Acknowledge and state \
the concrete next step you're taking. If the context includes \
"heuristic_commitment_signal_detected": true, this is a strong, near-certain signal — treat any \
further qualifying question as a hard failure, no exceptions.
- If the message is hostile or asks to stop, use action="end" with a short, non-defensive \
rationale — do not apologize excessively, do not argue, just exit gracefully. If action=send is \
still appropriate (e.g. a single graceful acknowledgment before ending), keep it to one line.
- If off-topic (e.g. asks about something unrelated to Vera's job), politely decline to help with \
the unrelated ask and redirect back to the original thread in one sentence — action="send".
- Never repeat a body verbatim that was already sent in this conversation."""


def compose_reply(category: dict | None, merchant: dict | None, trigger: dict | None,
                   customer: dict | None, conversation_turns: list[dict],
                   incoming_message: str, commitment_hint: bool = False) -> dict[str, Any]:
    """Multi-turn reply composition (used by /v1/reply).

    commitment_hint: set by a cheap keyword heuristic in main.py before this is
    called. The LLM is instructed to treat clear commitment language as an
    action-mode trigger regardless, but surfacing the heuristic's verdict
    explicitly makes that transition more reliable than hoping the model
    parses it correctly from raw text alone — this is the single highest-value
    failure mode called out in the challenge brief (§9, Pattern D).
    """

    payload = {
        "category": category or {},
        "merchant": merchant or {},
        "trigger": trigger or {},
        "customer": customer,
        "conversation_so_far": conversation_turns,
        "incoming_message": incoming_message,
        "heuristic_commitment_signal_detected": commitment_hint,
    }

    user_prompt = (
        "CONTEXT (JSON):\n" + json.dumps(payload, indent=2, default=str) +
        "\n\nDecide your next move now. Return ONLY the JSON object described in your instructions."
    )

    client = _get_client()
    resp = client.messages.create(
        model=MODEL,
        max_tokens=500,
        temperature=0.3,
        system=REPLY_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_prompt}],
    )
    raw = resp.content[0].text
    data = _extract_json(raw)
    data.setdefault("action", "send")
    if data["action"] == "send":
        data.setdefault("cta", "open_ended")
    return data
